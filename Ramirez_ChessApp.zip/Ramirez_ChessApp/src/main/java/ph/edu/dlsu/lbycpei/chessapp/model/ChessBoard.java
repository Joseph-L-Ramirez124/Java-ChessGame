package ph.edu.dlsu.lbycpei.chessapp.model;

import ph.edu.dlsu.lbycpei.chessapp.model.pieces.*;

import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class ChessBoard implements ChessBoardInterface {

    private ChessPiece[][] board;

    public ChessBoard() {
        board = new ChessPiece[8][8];
        initializeBoard();
    }

    @Override
    public ChessPiece pieceAt(int row, int col) {
        if (row >= 0 && row < 8 && col >= 0 && col < 8) {
            return board[row][col];
        }
        return null;
    }

    @Override
    public void addPiece(ChessPiece piece) {
        if (piece != null) {
            board[piece.getRow()][piece.getCol()] = piece;
        }
    }

    @Override
    public void removePiece(int row, int col) {
        if (row >= 0 && row < 8 && col >= 0 && col < 8) {
            board[row][col] = null;
        }
    }

    public void initializeBoard() {

        addPiece(new Rook(0, 0, 1));
        addPiece(new Knight(0, 1, 1));
        addPiece(new Bishop(0, 2, 1));
        addPiece(new Queen(0, 3, 1));
        addPiece(new King(0, 4, 1));
        addPiece(new Bishop(0, 5, 1));
        addPiece(new Knight(0, 6, 1));
        addPiece(new Rook(0, 7, 1));


        for (int col = 0; col < 8; col++) {
            addPiece(new Pawn(1, col, 1));
        }


        for (int col = 0; col < 8; col++) {
            addPiece(new Pawn(6, col, 0));
        }


        addPiece(new Rook(7, 0, 0));
        addPiece(new Knight(7, 1, 0));
        addPiece(new Bishop(7, 2, 0));
        addPiece(new Queen(7, 3, 0));
        addPiece(new King(7, 4, 0));
        addPiece(new Bishop(7, 5, 0));
        addPiece(new Knight(7, 6, 0));
        addPiece(new Rook(7, 7, 0));
    }

    public void clearBoard() {
        for (ChessPiece[] row : board) {
            Arrays.fill(row, null);
        }
    }

    public void setBoardFromArray(ChessPiece[][] pieces) {
        for (int i = 0; i < pieces.length; i++) {
            for (int j = 0; j < pieces[i].length; j++) {
                board[i][j] = pieces[i][j];
            }
        }
    }

    public List<int[]> getLegalMoves(int row, int col) {
        List<int[]> moves = new ArrayList<>();

        ChessPiece piece = pieceAt(row, col);
        if (piece == null) return moves;

        int color = piece.getColor();

        switch (piece.getType()) {
            case PAWN -> {
                int direction = (color == ChessPiece.WHITE) ? -1 : 1;
                int nextRow = row + direction;

                // Forward move
                if (isInBounds(nextRow, col) && pieceAt(nextRow, col) == null) {
                    moves.add(new int[]{nextRow, col});

                    // First move: two steps
                    int startRow = (color == ChessPiece.WHITE) ? 6 : 1;
                    int twoStepRow = row + 2 * direction;
                    if (row == startRow && pieceAt(twoStepRow, col) == null) {
                        moves.add(new int[]{twoStepRow, col});
                    }
                }

                // Diagonal captures
                for (int dCol : new int[]{-1, 1}) {
                    int c = col + dCol;
                    if (isInBounds(nextRow, c)) {
                        ChessPiece target = pieceAt(nextRow, c);
                        if (target != null && target.getColor() != color) {
                            moves.add(new int[]{nextRow, c});
                        }
                    }
                }
            }

            case KNIGHT -> {
                int[][] deltas = {
                        {-2, -1}, {-2, 1}, {-1, -2}, {-1, 2},
                        {1, -2}, {1, 2}, {2, -1}, {2, 1}
                };
                for (int[] d : deltas) {
                    int r = row + d[0], c = col + d[1];
                    if (isInBounds(r, c)) {
                        ChessPiece target = pieceAt(r, c);
                        if (target == null || target.getColor() != color) {
                            moves.add(new int[]{r, c});
                        }
                    }
                }
            }

            case ROOK -> addLinearMoves(moves, row, col, color, new int[][]{
                    {1, 0}, {-1, 0}, {0, 1}, {0, -1}
            });

            case BISHOP -> addLinearMoves(moves, row, col, color, new int[][]{
                    {1, 1}, {-1, -1}, {1, -1}, {-1, 1}
            });

            case QUEEN -> addLinearMoves(moves, row, col, color, new int[][]{
                    {1, 0}, {-1, 0}, {0, 1}, {0, -1},
                    {1, 1}, {-1, -1}, {1, -1}, {-1, 1}
            });

            case KING -> {
                int[][] deltas = {
                        {1, 0}, {-1, 0}, {0, 1}, {0, -1},
                        {1, 1}, {-1, -1}, {1, -1}, {-1, 1}
                };
                for (int[] d : deltas) {
                    int r = row + d[0], c = col + d[1];
                    if (isInBounds(r, c)) {
                        ChessPiece target = pieceAt(r, c);
                        if (target == null || target.getColor() != color) {
                            moves.add(new int[]{r, c});
                        }
                    }
                }
            }
        }

        return moves;
    }

    private boolean isInBounds(int row, int col) {
        return row >= 0 && row < 8 && col >= 0 && col < 8;
    }

    private void addLinearMoves(List<int[]> moves, int row, int col, int color, int[][] directions) {
        for (int[] dir : directions) {
            int r = row + dir[0];
            int c = col + dir[1];

            while (isInBounds(r, c)) {
                ChessPiece target = pieceAt(r, c);
                if (target == null) {
                    moves.add(new int[]{r, c});
                } else {
                    if (target.getColor() != color) {
                        moves.add(new int[]{r, c});
                    }
                    break;
                }
                r += dir[0];
                c += dir[1];
            }
        }
    }
}
